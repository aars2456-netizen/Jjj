<?php
require_once __DIR__ . '/includes/functions.php';
$user = current_user();
$page_title = 'AverionLand — кубическое приключение';
require __DIR__ . '/includes/header.php';
?>
<main id="top">
<section class="hero">
<div class="hero-art">
<img src="/assets/banner.png" alt="Мир AverionLand">
<div class="hero-shade"></div>
<div class="hero-vignette"></div>
</div>
<div class="hero-content">
<div class="eyebrow"><span></span> Кубический мир, который хочется исследовать</div>
<h1>AverionLand — увлекательное <strong>кубическое приключение</strong></h1>
<p class="lead">AverionLand приглашает вас в захватывающее кубическое приключение!</p>
<p class="description">Мы представляем собой уникальный серверный проект в аниме-стиле, обогащенный множеством увлекательных дополнений. Приготовьтесь к захватывающим путешествиям между измерениями, где технологии гармонично переплетаются с магией.</p>
<div class="stats">
<div class="stat"><span class="status-dot"></span><div><b>Скоро открытие</b><small>Статус проекта</small></div></div>
<div class="stat"><b>20 TPS</b><small>Стабильная игра</small></div>
</div>
<a class="start" href="/ru/servers/"><span>НАЧАТЬ ИГРУ</span><i>→</i></a>
</div>
</section>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
