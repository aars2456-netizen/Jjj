CREATE TABLE IF NOT EXISTS profile_assets (
    user_id INT UNSIGNED NOT NULL,
    avatar_path VARCHAR(255) NULL,
    avatar_scale DECIMAL(5,2) NOT NULL DEFAULT 1.00,
    avatar_x DECIMAL(7,2) NOT NULL DEFAULT 0,
    avatar_y DECIMAL(7,2) NOT NULL DEFAULT 0,
    avatar_rotation DECIMAL(7,2) NOT NULL DEFAULT 0,
    avatar_invert TINYINT(1) NOT NULL DEFAULT 0,
    skin_path VARCHAR(255) NULL,
    cape_path VARCHAR(255) NULL,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id),
    CONSTRAINT fk_profile_assets_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
