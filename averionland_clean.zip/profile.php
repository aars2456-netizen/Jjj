<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/functions.php';

$user = require_auth();

function profile_upload_dir(): string
{
    return __DIR__ . '/uploads/profile/' . (int)$_SESSION['user_id'];
}

function profile_public_path(string $type, string $name): string
{
    return '/uploads/profile/' . (int)$_SESSION['user_id'] . '/' . $type . '/' . rawurlencode($name);
}

function profile_default_asset(): array
{
    return [
        'avatar_path' => null, 'avatar_scale' => 1, 'avatar_x' => 0, 'avatar_y' => 0,
        'avatar_rotation' => 0, 'avatar_invert' => 0, 'skin_path' => null, 'cape_path' => null
    ];
}

function profile_json_path(int $userId): string
{
    return profile_upload_dir() . '/profile.json';
}

function profile_asset(PDO $pdo, int $userId): array
{
    $asset = profile_default_asset();
    try {
        $stmt = $pdo->prepare('SELECT avatar_path, avatar_scale, avatar_x, avatar_y, avatar_rotation, avatar_invert, skin_path, cape_path FROM profile_assets WHERE user_id = ? LIMIT 1');
        $stmt->execute([$userId]);
        $dbAsset = $stmt->fetch();
        if ($dbAsset) {
            return array_merge($asset, $dbAsset);
        }
    } catch (Throwable $ignored) {
    }
    $path = profile_json_path($userId);
    if (is_file($path)) {
        $data = json_decode((string)file_get_contents($path), true);
        if (is_array($data)) {
            $asset = array_merge($asset, $data);
        }
    }
    return $asset;
}

function ensure_profile_assets(PDO $pdo): bool
{
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS profile_assets (
            user_id INT UNSIGNED NOT NULL,
            avatar_path VARCHAR(255) NULL,
            avatar_scale DECIMAL(5,2) NOT NULL DEFAULT 1.00,
            avatar_x DECIMAL(7,2) NOT NULL DEFAULT 0,
            avatar_y DECIMAL(7,2) NOT NULL DEFAULT 0,
            avatar_rotation DECIMAL(7,2) NOT NULL DEFAULT 0,
            avatar_invert TINYINT(1) NOT NULL DEFAULT 0,
            skin_path VARCHAR(255) NULL,
            cape_path VARCHAR(255) NULL,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        return true;
    } catch (Throwable $ignored) {
        return false;
    }
}

function save_profile_asset(PDO $pdo, int $userId, array $asset): void
{
    $dir = profile_upload_dir();
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    file_put_contents(profile_json_path($userId), json_encode($asset, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX);
    try {
        $stmt = $pdo->prepare('INSERT INTO profile_assets (user_id, avatar_path, avatar_scale, avatar_x, avatar_y, avatar_rotation, avatar_invert, skin_path, cape_path) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE avatar_path=VALUES(avatar_path), avatar_scale=VALUES(avatar_scale), avatar_x=VALUES(avatar_x), avatar_y=VALUES(avatar_y), avatar_rotation=VALUES(avatar_rotation), avatar_invert=VALUES(avatar_invert), skin_path=VALUES(skin_path), cape_path=VALUES(cape_path)');
        $stmt->execute([
            $userId, $asset['avatar_path'], $asset['avatar_scale'], $asset['avatar_x'], $asset['avatar_y'],
            $asset['avatar_rotation'], $asset['avatar_invert'], $asset['skin_path'], $asset['cape_path']
        ]);
    } catch (Throwable $ignored) {
    }
}

function safe_image_upload(array $file, array $allowedMime, int $maxBytes): array
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Не удалось загрузить файл.');
    }
    if (($file['size'] ?? 0) <= 0 || $file['size'] > $maxBytes) {
        throw new RuntimeException('Файл слишком большой.');
    }
    $tmp = $file['tmp_name'] ?? '';
    if (!is_uploaded_file($tmp)) {
        throw new RuntimeException('Некорректная загрузка файла.');
    }
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($tmp);
    if (!in_array($mime, $allowedMime, true)) {
        throw new RuntimeException('Неподдерживаемый формат изображения.');
    }
    $info = @getimagesize($tmp);
    if (!$info || empty($info[0]) || empty($info[1])) {
        throw new RuntimeException('Файл не является изображением.');
    }
    return [$mime, (int)$info[0], (int)$info[1]];
}

function save_uploaded_asset(array $file, string $type, array $allowedMime, int $maxBytes, int $userId): string
{
    [$mime] = safe_image_upload($file, $allowedMime, $maxBytes);
    $ext = match ($mime) {
        'image/gif' => 'gif',
        'image/png' => 'png',
        'image/jpeg' => 'jpg',
        'image/webp' => 'webp',
        default => 'bin'
    };
    $dir = profile_upload_dir() . '/' . $type;
    if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) {
        throw new RuntimeException('Не удалось создать папку загрузок.');
    }
    $name = bin2hex(random_bytes(16)) . '.' . $ext;
    $target = $dir . '/' . $name;
    if (!move_uploaded_file($file['tmp_name'], $target)) {
        throw new RuntimeException('Не удалось сохранить файл.');
    }
    return '/uploads/profile/' . $userId . '/' . $type . '/' . $name;
}

$pdo = db();
ensure_profile_assets($pdo);
$userId = (int)$user['id'];
$asset = profile_asset($pdo, $userId);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!verify_csrf((string)($_POST['csrf_token'] ?? ''))) {
            throw new RuntimeException('Сессия формы устарела. Обновите страницу.');
        }
        $action = (string)($_POST['action'] ?? '');

        if ($action === 'save_avatar') {
            $avatarPath = $asset['avatar_path'];
            if (!empty($_FILES['avatar']['name'])) {
                $avatarPath = save_uploaded_asset($_FILES['avatar'], 'avatar', ['image/png','image/jpeg','image/gif','image/webp'], 12 * 1024 * 1024, $userId);
            }
            if (!$avatarPath) {
                throw new RuntimeException('Сначала выберите аватарку.');
            }
            $scale = max(0.5, min(3, (float)($_POST['avatar_scale'] ?? 1)));
            $x = max(-100, min(100, (float)($_POST['avatar_x'] ?? 0)));
            $y = max(-100, min(100, (float)($_POST['avatar_y'] ?? 0)));
            $rotation = max(-180, min(180, (float)($_POST['avatar_rotation'] ?? 0)));
            $invert = !empty($_POST['avatar_invert']) ? 1 : 0;
            $asset['avatar_path'] = $avatarPath;
            $asset['avatar_scale'] = $scale;
            $asset['avatar_x'] = $x;
            $asset['avatar_y'] = $y;
            $asset['avatar_rotation'] = $rotation;
            $asset['avatar_invert'] = $invert;
            save_profile_asset($pdo, $userId, $asset);
            set_flash('success', 'Аватарка сохранена.');
        } elseif ($action === 'save_skin') {
            if (empty($_FILES['skin']['name']) && empty($asset['skin_path'])) {
                throw new RuntimeException('Выберите скин.');
            }
            $skinPath = $asset['skin_path'];
            if (!empty($_FILES['skin']['name'])) {
                [, $w, $h] = safe_image_upload($_FILES['skin'], ['image/png'], 4 * 1024 * 1024);
                if (!in_array([$w, $h], [[64,64],[64,32],[128,128],[128,64]], true)) {
                    throw new RuntimeException('Скин должен быть PNG 64×64, 64×32, 128×128 или 128×64.');
                }
                $skinPath = save_uploaded_asset($_FILES['skin'], 'skin', ['image/png'], 4 * 1024 * 1024, $userId);
            }
            $asset['skin_path'] = $skinPath;
            save_profile_asset($pdo, $userId, $asset);
            set_flash('success', 'Скин сохранён.');
        } elseif ($action === 'save_cape') {
            if (empty($_FILES['cape']['name']) && empty($asset['cape_path'])) {
                throw new RuntimeException('Выберите плащ.');
            }
            $capePath = $asset['cape_path'];
            if (!empty($_FILES['cape']['name'])) {
                [, $w, $h] = safe_image_upload($_FILES['cape'], ['image/png'], 4 * 1024 * 1024);
                if ($w < 32 || $h < 32 || $w > 2048 || $h > 2048) {
                    throw new RuntimeException('Слишком большой или маленький файл плаща.');
                }
                $capePath = save_uploaded_asset($_FILES['cape'], 'cape', ['image/png'], 4 * 1024 * 1024, $userId);
            }
            $asset['cape_path'] = $capePath;
            save_profile_asset($pdo, $userId, $asset);
            set_flash('success', 'Плащ сохранён.');
        } elseif ($action === 'delete_avatar') {
            $asset['avatar_path'] = null;
            save_profile_asset($pdo, $userId, $asset);
            set_flash('success', 'Аватарка удалена.');
        } elseif ($action === 'delete_asset') {
            $type = (string)($_POST['type'] ?? '');
            switch ($type) {
                case 'avatar': $column = 'avatar_path'; break;
                case 'skin': $column = 'skin_path'; break;
                case 'cape': $column = 'cape_path'; break;
                default: $column = null;
            }
            if (!$column) throw new RuntimeException('Неизвестный тип файла.');
            $asset[$column] = null;
            save_profile_asset($pdo, $userId, $asset);
            set_flash('success', 'Файл удалён.');
        } else {
            throw new RuntimeException('Неизвестное действие.');
        }
    } catch (Throwable $e) {
        set_flash('error', $e->getMessage());
    }
    redirect('/ru/profile/');
}

$asset = profile_asset($pdo, $userId);
$page_title = 'Профиль — AverionLand';
require __DIR__ . '/includes/header.php';
$avatarStyle = 'transform:translate(' . (float)$asset['avatar_x'] . '%, ' . (float)$asset['avatar_y'] . '%) scale(' . (float)$asset['avatar_scale'] . ') rotate(' . (float)$asset['avatar_rotation'] . 'deg);' . (!empty($asset['avatar_invert']) ? 'filter:invert(1);' : '');
?>
<main class="profile-page">
<section class="profile-shell">
    <div class="profile-heading">
        <div>
            <div class="profile-kicker">ПРОФИЛЬ</div>
            <h1><?= e($user['username']) ?></h1>
        </div>
        <div class="profile-avatar-small <?= $asset['avatar_path'] ? '' : 'empty' ?>">
            <?php if ($asset['avatar_path']): ?><img src="<?= e($asset['avatar_path']) ?>" alt="Аватар" style="<?= e($avatarStyle) ?>"><?php else: ?><span>+</span><?php endif; ?>
        </div>
    </div>

    <section class="profile-card avatar-card">
        <div class="card-title-row"><h2>Аватарка</h2><span>PNG / JPG / GIF / WEBP</span></div>
        <form method="post" enctype="multipart/form-data" class="asset-form">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="action" value="save_avatar">
            <label class="upload-button"><input type="file" name="avatar" accept="image/png,image/jpeg,image/gif,image/webp">ЗАГРУЗИТЬ АВАТАРКУ</label>
            <div class="avatar-editor-grid">
                <div class="avatar-preview-wrap"><div class="avatar-preview"><div class="avatar-preview-inner <?= !empty($asset['avatar_invert']) ? 'is-inverted' : '' ?>" id="avatarPreview"><span class="preview-placeholder">АВАТАР</span><?php if ($asset['avatar_path']): ?><img id="avatarPreviewImage" src="<?= e($asset['avatar_path']) ?>" alt="" style="<?= e($avatarStyle) ?>"><?php else: ?><img id="avatarPreviewImage" src="" alt="" hidden><?php endif; ?></div></div></div>
                <div class="avatar-controls">
                    <label>МАСШТАБ <output id="scaleOut"><?= e((string)$asset['avatar_scale']) ?></output><input id="scale" name="avatar_scale" type="range" min="0.5" max="3" step="0.01" value="<?= e((string)$asset['avatar_scale']) ?>"></label>
                    <label>ПО ГОРИЗОНТАЛИ <output id="xOut"><?= e((string)$asset['avatar_x']) ?>%</output><input id="posX" name="avatar_x" type="range" min="-100" max="100" step="1" value="<?= e((string)$asset['avatar_x']) ?>"></label>
                    <label>ПО ВЕРТИКАЛИ <output id="yOut"><?= e((string)$asset['avatar_y']) ?>%</output><input id="posY" name="avatar_y" type="range" min="-100" max="100" step="1" value="<?= e((string)$asset['avatar_y']) ?>"></label>
                    <label>ПОВОРОТ <output id="rotationOut"><?= e((string)$asset['avatar_rotation']) ?>°</output><input id="rotation" name="avatar_rotation" type="range" min="-180" max="180" step="1" value="<?= e((string)$asset['avatar_rotation']) ?>"></label>
                    <label class="switch-row"><input id="invert" name="avatar_invert" type="checkbox" value="1" <?= !empty($asset['avatar_invert']) ? 'checked' : '' ?>><span>ИНВЕРСИЯ</span></label>
                </div>
            </div>
            <div class="form-actions"><button class="outline-button" type="submit">СОХРАНИТЬ</button><?php if ($asset['avatar_path']): ?><button class="text-button danger" name="action" value="delete_avatar" type="button" id="deleteAvatar">УДАЛИТЬ</button><?php endif; ?></div>
        </form>
        <?php if ($asset['avatar_path']): ?><form id="deleteAvatarForm" method="post" hidden><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="delete_asset"><input type="hidden" name="type" value="avatar"></form><?php endif; ?>
    </section>

    <section class="profile-card">
        <div class="card-title-row"><h2>Скин</h2><span>PNG</span></div>
        <div class="asset-preview minecraft-preview"><?php if ($asset['skin_path']): ?><img src="<?= e($asset['skin_path']) ?>" alt="Скин"><?php else: ?><div class="empty-asset">СКИН НЕ УСТАНОВЛЕН</div><?php endif; ?></div>
        <form method="post" enctype="multipart/form-data" class="asset-row-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="save_skin"><label class="upload-button compact"><input type="file" name="skin" accept="image/png">ЗАГРУЗИТЬ СКИН</label><?php if ($asset['skin_path']): ?><button class="text-button danger" type="submit" name="action" value="delete_asset">УДАЛИТЬ</button><input type="hidden" name="type" value="skin"><?php endif; ?></form>
    </section>

    <section class="profile-card">
        <div class="card-title-row"><h2>Плащ</h2><span>PNG</span></div>
        <div class="asset-preview cape-preview"><?php if ($asset['cape_path']): ?><img src="<?= e($asset['cape_path']) ?>" alt="Плащ"><?php else: ?><div class="empty-asset">ПЛАЩ НЕ УСТАНОВЛЕН</div><?php endif; ?></div>
        <form method="post" enctype="multipart/form-data" class="asset-row-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="save_cape"><label class="upload-button compact"><input type="file" name="cape" accept="image/png">ЗАГРУЗИТЬ ПЛАЩ</label><?php if ($asset['cape_path']): ?><button class="text-button danger" type="submit" name="action" value="delete_asset">УДАЛИТЬ</button><input type="hidden" name="type" value="cape"><?php endif; ?></form>
    </section>
</section>
</main>
<script>
(() => {
  const file = document.querySelector('input[name="avatar"]');
  const img = document.getElementById('avatarPreviewImage');
  const placeholder = document.querySelector('.preview-placeholder');
  const preview = document.getElementById('avatarPreview');
  const scale = document.getElementById('scale'), posX = document.getElementById('posX'), posY = document.getElementById('posY'), rotation = document.getElementById('rotation'), invert = document.getElementById('invert');
  if (!scale) return;
  const update = () => {
    const s = scale.value, x = posX.value, y = posY.value, r = rotation.value;
    img.style.transform = `translate(${x}%, ${y}%) scale(${s}) rotate(${r}deg)`;
    img.style.filter = invert.checked ? 'invert(1)' : 'none';
    document.getElementById('scaleOut').textContent = s;
    document.getElementById('xOut').textContent = x + '%';
    document.getElementById('yOut').textContent = y + '%';
    document.getElementById('rotationOut').textContent = r + '°';
  };
  [scale,posX,posY,rotation,invert].forEach(el => el.addEventListener('input', update));
  file?.addEventListener('change', () => {
    const f = file.files[0]; if (!f) return;
    img.src = URL.createObjectURL(f); img.hidden = false; placeholder.hidden = true; update();
  });
  document.getElementById('deleteAvatar')?.addEventListener('click', () => document.getElementById('deleteAvatarForm').submit());
})();
</script>
<?php require __DIR__ . '/includes/footer.php'; ?>
