<?php
require_once __DIR__ . '/includes/functions.php';
$user = current_user();
$page_title = 'Сервера — AverionLand';
require __DIR__ . '/includes/header.php';
?>
<main class="servers-page">
<section class="servers-intro">
<span class="section-kicker">AVERIONLAND</span>
<h1>Сервера</h1>
<p>Выберите мир для своего следующего приключения.</p>
</section>
<section class="server-list">
<article class="server-card">
<div class="server-cover"><img src="/assets/banner.png" alt="AverionLand"><div class="server-cover-shade"></div><div class="server-badges"><span>АНИМЕ-СТИЛЬ</span><span>СКОРО ОТКРЫТИЕ</span></div></div>
<div class="server-body">
<div class="server-title"><img src="/assets/server-icon.png" alt=""><div><h2>OneBlock</h2><p>Кубическое приключение</p></div></div>
<h3>Для лучших из лучших</h3>
<p class="server-description">Уникальный серверный проект в аниме-стиле, где технологии гармонично переплетаются с магией. Вас ждут путешествия между измерениями, необычные механики и множество увлекательных дополнений.</p>
<div class="server-info"><div><span>Онлайн</span><strong class="soon">Скоро открытие</strong></div><div><span>Статус</span><strong class="soon">Скоро открытие</strong></div></div>
<div class="server-actions"><button type="button" disabled>СЕРВЕР ЕЩЁ НЕ ОТКРЫТ</button></div>
</div>
</article>
</section>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
