<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/functions.php';
$user = require_auth();

$avatarPath = $user['avatar_path'] ?? null;

$page_title = 'Личный кабинет — AverionLand';
require __DIR__ . '/includes/header.php';
?>
<main class="account-page">
    <section class="account-shell">
        <div class="account-card cabinet-card">
            <div class="cabinet-identity">
                <div class="cabinet-avatar">
                    <?php if ($avatarPath): ?>
                        <img src="<?= e($avatarPath) ?>" alt="">
                    <?php else: ?>
                        <?= e(mb_strtoupper(mb_substr($user['username'], 0, 1))) ?>
                    <?php endif; ?>
                </div>
                <div>
                    <div class="cabinet-label">ЛИЧНЫЙ КАБИНЕТ</div>
                    <h1><?= e($user['username']) ?></h1>
                </div>
            </div>

            <a class="cabinet-profile-button" href="/ru/profile/">АВАТАР, СКИН И ПЛАЩ</a>
        </div>
    </section>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
