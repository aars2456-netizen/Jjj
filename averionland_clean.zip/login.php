<?php
require_once __DIR__ . '/includes/functions.php';
require_guest();

$error = '';
$oldUsername = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $oldUsername = trim((string)($_POST['username'] ?? ''));
    $password = (string)($_POST['password'] ?? '');

    if (!verify_csrf((string)($_POST['csrf_token'] ?? ''))) {
        $error = 'Сессия формы устарела. Обновите страницу и попробуйте снова.';
    } elseif ($oldUsername === '' || $password === '') {
        $error = 'Заполните все поля.';
    } else {
        try {
            $stmt = db()->prepare('SELECT id, username, email, password_hash, email_verified FROM users WHERE username = ? OR email = ? LIMIT 1');
            $stmt->execute([$oldUsername, strtolower($oldUsername)]);
            $user = $stmt->fetch();

            if (!$user || !password_verify($password, $user['password_hash'])) {
                $error = 'Неверный никнейм или пароль.';
            } elseif ((int)$user['email_verified'] !== 1) {
                start_session();
                $_SESSION['pending_verification_user_id'] = (int)$user['id'];
                $error = 'Сначала подтвердите адрес электронной почты.';
            } else {
                start_session();
                session_regenerate_id(true);
                $_SESSION['user_id'] = (int)$user['id'];
                redirect('account.php');
            }
        } catch (Throwable $e) {
            $error = 'Не удалось выполнить вход. Проверьте подключение к базе данных.';
        }
    }
}

$page_title = 'Войти — AverionLand';
require __DIR__ . '/includes/header.php';
?>
<main class="auth-page">
<section class="auth-card">
<h1>Войти</h1>
<?php if ($error): ?><div class="message error"><?= e($error) ?></div><?php endif; ?>
<form class="auth-form" method="post" action="/ru/login/">
<input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
<div class="input-wrap">
<input type="text" name="username" value="<?= e($oldUsername) ?>" placeholder="Игровой никнейм" maxlength="190" required autocomplete="username">
<svg class="input-icon" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 12a5 5 0 1 0-5-5 5 5 0 0 0 5 5Zm0 2c-4.42 0-8 2.24-8 5v1h16v-1c0-2.76-3.58-5-8-5Z"/></svg>
</div>
<div class="input-wrap">
<input type="password" name="password" placeholder="Пароль" required autocomplete="current-password">
<svg class="input-icon" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M17 9h-1V7a4 4 0 0 0-8 0v2H7a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-7a2 2 0 0 0-2-2Zm-7-2a2 2 0 0 1 4 0v2h-4V7Zm2 9a2 2 0 1 1 0-4 2 2 0 0 1 0 4Z"/></svg>
</div>
<button class="auth-submit accent" type="submit">ВОЙТИ</button>
</form>
<div class="auth-links"><a href="/ru/register/">РЕГИСТРАЦИЯ</a><span></span></div>
</section>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
