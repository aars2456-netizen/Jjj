<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/mail.php';
require_guest();
start_session();

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !verify_csrf((string)($_POST['csrf_token'] ?? ''))) {
    set_flash('error', 'Некорректный запрос.');
    redirect('/ru/verify/');
}

$userId = (int)($_SESSION['pending_verification_user_id'] ?? 0);
if ($userId <= 0) {
    redirect('/ru/register/');
}

$stmt = db()->prepare('SELECT id, username, email, email_verified FROM users WHERE id = ? LIMIT 1');
$stmt->execute([$userId]);
$user = $stmt->fetch();

if (!$user) {
    unset($_SESSION['pending_verification_user_id']);
    redirect('/ru/register/');
}

if ((int)$user['email_verified'] === 1) {
    $_SESSION['user_id'] = $userId;
    unset($_SESSION['pending_verification_user_id']);
    redirect('/ru/account/');
}

$stmt = db()->prepare('SELECT last_sent_at FROM email_verifications WHERE user_id = ? LIMIT 1');
$stmt->execute([$userId]);
$row = $stmt->fetch();

if ($row && strtotime($row['last_sent_at']) + RESEND_COOLDOWN > time()) {
    $wait = strtotime($row['last_sent_at']) + RESEND_COOLDOWN - time();
    set_flash('error', 'Повторная отправка будет доступна через ' . max(1, $wait) . ' сек.');
    redirect('/ru/verify/');
}

$token = bin2hex(random_bytes(32));
$tokenHash = password_hash($token, PASSWORD_DEFAULT);
$expires = date('Y-m-d H:i:s', time() + CODE_LIFETIME);
$now = date('Y-m-d H:i:s');

try {
    $pdo = db();
    $pdo->beginTransaction();
    $stmt = $pdo->prepare('INSERT INTO email_verifications (user_id, code_hash, expires_at, last_sent_at) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE code_hash = VALUES(code_hash), expires_at = VALUES(expires_at), last_sent_at = VALUES(last_sent_at), created_at = CURRENT_TIMESTAMP');
    $stmt->execute([$userId, $tokenHash, $expires, $now]);

    if (!send_verification_email($userId, $user['email'], $user['username'], $token)) {
        $pdo->rollBack();
        set_flash('error', 'Не удалось отправить письмо. Проверьте настройки SMTP в config.php.');
        redirect('/ru/verify/');
    }

    $pdo->commit();
    set_flash('success', 'Новое письмо отправлено на вашу почту.');
} catch (Throwable $e) {
    if (isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    set_flash('error', 'Не удалось отправить письмо. Проверьте настройки SMTP.');
}

redirect('/ru/verify/');
