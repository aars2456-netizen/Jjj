<?php
declare(strict_types=1);

const DB_HOST = 'localhost';
const DB_NAME = 'averion';
const DB_USER = 'averionland';
const DB_PASS = '';

const SMTP_HOST = 'smtp.gmail.com';
const SMTP_PORT = 587;
const SMTP_USER = 'averionland@gmail.com';
const SMTP_PASS = '';
const SMTP_FROM = 'averionland@gmail.com';
const SMTP_NAME = 'AverionLand';

const CODE_LIFETIME = 600;
const RESEND_COOLDOWN = 60;

date_default_timezone_set('Europe/Moscow');
