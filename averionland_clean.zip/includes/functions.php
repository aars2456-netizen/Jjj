<?php
declare(strict_types=1);

require_once __DIR__ . '/../config.php';

function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
    return $pdo;
}

function start_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}

function csrf_token(): string
{
    start_session();
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf(string $token): bool
{
    start_session();
    return !empty($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function redirect(string $url): never
{
    $routes = [
        'index.php' => '/',
        'register.php' => '/ru/register/',
        'login.php' => '/ru/login/',
        'verify.php' => '/ru/verify/',
        'resend-code.php' => '/ru/resend-code/',
        'account.php' => '/ru/account/',
        'logout.php' => '/ru/logout/',
        'servers.php' => '/ru/servers/',
        'profile.php' => '/ru/profile/'
    ];
    if (isset($routes[$url])) {
        $url = $routes[$url];
    }
    header('Location: ' . $url);
    exit;
}

function e(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function current_user(): ?array
{
    start_session();
    if (empty($_SESSION['user_id'])) {
        return null;
    }
    try {
        $stmt = db()->prepare('SELECT id, username, email, email_verified, created_at FROM users WHERE id = ? LIMIT 1');
        $stmt->execute([(int)$_SESSION['user_id']]);
        $user = $stmt->fetch();
        if ($user) {
            $user['avatar_path'] = null;
            try {
                $avatarStmt = db()->prepare('SELECT avatar_path FROM profile_assets WHERE user_id = ? LIMIT 1');
                $avatarStmt->execute([(int)$user['id']]);
                $avatar = $avatarStmt->fetch();
                $user['avatar_path'] = $avatar['avatar_path'] ?? null;
            } catch (Throwable $ignored) {
                $jsonPath = __DIR__ . '/../uploads/profile/' . (int)$user['id'] . '/profile.json';
                if (is_file($jsonPath)) {
                    $profileData = json_decode((string)file_get_contents($jsonPath), true);
                    if (is_array($profileData)) {
                        $user['avatar_path'] = $profileData['avatar_path'] ?? null;
                    }
                }
            }
        }
    } catch (Throwable $e) {
        return null;
    }
    if (!$user) {
        unset($_SESSION['user_id']);
        return null;
    }
    return $user;
}

function require_guest(): void
{
    if (current_user()) {
        redirect('account.php');
    }
}

function require_auth(): array
{
    $user = current_user();
    if (!$user) {
        redirect('login.php');
    }
    return $user;
}

function valid_username(string $username): bool
{
    return (bool)preg_match('/^[A-Za-zА-Яа-яЁё0-9_]{3,32}$/u', $username);
}

function generate_code(): string
{
    return str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
}

function set_flash(string $type, string $message): void
{
    start_session();
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function get_flash(): ?array
{
    start_session();
    $flash = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $flash;
}
