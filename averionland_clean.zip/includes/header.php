<?php
require_once __DIR__ . '/functions.php';
start_session();
$user = current_user();
$flash = get_flash();
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#080612">
<title><?= e($page_title ?? 'AverionLand') ?></title>
<link rel="icon" href="/assets/server-icon.png" type="image/png">
<link rel="stylesheet" href="/styles.css">
<link rel="stylesheet" href="/auth.css">
<link rel="stylesheet" href="/servers.css">
<link rel="stylesheet" href="/profile.css">
</head>
<body>
<div class="page-glow"></div>
<header class="header">
<a class="brand" href="/">AverionLand</a>
<?php if ($user): ?>
<div class="profile-chip"><a href="/ru/account/"><span class="profile-chip-avatar"><?php if (!empty($user['avatar_path'])): ?><img src="<?= e($user['avatar_path']) ?>" alt=""><?php else: ?><?= e(mb_strtoupper(mb_substr($user['username'], 0, 1))) ?><?php endif; ?></span><span><?= e($user['username']) ?></span></a></div>
<?php endif; ?>
<nav class="nav" id="site-nav">
<a href="/">Главная</a>
<a href="/ru/servers/">Сервера</a>
<?php if ($user): ?>
<a href="/ru/account/">Аккаунт</a>
<a href="/ru/logout/">Выйти</a>
<?php else: ?>
<a href="/ru/login/">Войти</a>
<a href="/ru/register/">Регистрация</a>
<?php endif; ?>
</nav>
<button class="menu" type="button" aria-label="Открыть меню" aria-expanded="false"><span></span><span></span><span></span></button>
</header>
<?php if ($flash): ?>
<div class="flash <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
<?php endif; ?>
