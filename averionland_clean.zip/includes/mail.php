<?php
declare(strict_types=1);

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/functions.php';

function smtp_send(string $to, string $subject, string $html): bool
{
    if (SMTP_USER === '' || SMTP_PASS === '') {
        return false;
    }

    $socket = fsockopen('tcp://' . SMTP_HOST, SMTP_PORT, $errno, $errstr, 20);
    if (!$socket) {
        return false;
    }

    stream_set_timeout($socket, 20);

    try {
        smtp_expect($socket, [220]);
        smtp_command($socket, 'EHLO averionland.ru', [250]);
        smtp_command($socket, 'STARTTLS', [220]);

        $crypto = stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
        if ($crypto !== true) {
            fclose($socket);
            return false;
        }

        smtp_command($socket, 'EHLO averionland.ru', [250]);
        smtp_command($socket, 'AUTH LOGIN', [334]);
        smtp_command($socket, base64_encode(SMTP_USER), [334]);
        smtp_command($socket, base64_encode(SMTP_PASS), [235]);
        smtp_command($socket, 'MAIL FROM:<' . SMTP_FROM . '>', [250]);
        smtp_command($socket, 'RCPT TO:<' . $to . '>', [250, 251]);
        smtp_command($socket, 'DATA', [354]);

        $encodedSubject = '=?UTF-8?B?' . base64_encode($subject) . '?=';
        $message = 'From: ' . '=?UTF-8?B?' . base64_encode(SMTP_NAME) . '?=' . ' <' . SMTP_FROM . ">\r\n";
        $message .= 'To: <' . $to . ">\r\n";
        $message .= 'Subject: ' . $encodedSubject . "\r\n";
        $message .= "MIME-Version: 1.0\r\n";
        $message .= "Content-Type: text/html; charset=UTF-8\r\n";
        $message .= "Content-Transfer-Encoding: 8bit\r\n";
        $message .= "\r\n";
        $message .= $html;
        $message = preg_replace('/^\./m', '..', $message) . "\r\n.";

        fwrite($socket, $message . "\r\n");
        smtp_expect($socket, [250]);
        fwrite($socket, "QUIT\r\n");
        fclose($socket);
        return true;
    } catch (Throwable $e) {
        fclose($socket);
        return false;
    }
}

function smtp_command($socket, string $command, array $codes): string
{
    fwrite($socket, $command . "\r\n");
    return smtp_expect($socket, $codes);
}

function smtp_expect($socket, array $codes): string
{
    $response = '';
    while (($line = fgets($socket, 515)) !== false) {
        $response .= $line;
        if (preg_match('/^\d{3} /', $line)) {
            break;
        }
    }
    $code = (int)substr($response, 0, 3);
    if (!in_array($code, $codes, true)) {
        throw new RuntimeException('SMTP error');
    }
    return $response;
}

function send_verification_email(int $userId, string $email, string $username, string $token): bool
{
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? '';
    $verifyUrl = $scheme . '://' . $host . '/ru/verify/?uid=' . $userId . '&token=' . rawurlencode($token);
    $subject = 'Подтверждение регистрации AverionLand';
    $html = '<!doctype html><html lang="ru"><body style="margin:0;background:#080612;color:#f8f7fb;font-family:Arial,sans-serif;padding:30px"><div style="max-width:520px;margin:0 auto;background:#1f1b2b;border:1px solid rgba(255,255,255,.12);border-radius:24px;padding:34px;text-align:center"><h1 style="margin:0 0 20px;font-size:30px">AverionLand</h1><p style="font-size:17px;color:#d1ccd8">Здравствуйте, ' . e($username) . '!</p><p style="font-size:16px;color:#b5b0c2;margin:0 0 26px">Нажмите кнопку ниже, чтобы подтвердить адрес электронной почты и завершить регистрацию.</p><a href="' . e($verifyUrl) . '" style="display:inline-block;padding:16px 28px;border-radius:16px;background:linear-gradient(100deg,#ff8a45,#a8442f);border:2px solid #ffd77d;color:#fff;text-decoration:none;font-size:17px;font-weight:800">ПОДТВЕРДИТЬ РЕГИСТРАЦИЮ</a><p style="font-size:13px;color:#8f8999;margin:24px 0 0">Ссылка действует 10 минут.</p></div></body></html>';
    return smtp_send($email, $subject, $html);
}
