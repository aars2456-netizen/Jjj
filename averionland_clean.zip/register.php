<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/mail.php';
require_guest();

$error = '';
$oldUsername = '';
$oldEmail = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $oldUsername = trim((string)($_POST['username'] ?? ''));
    $oldEmail = strtolower(trim((string)($_POST['email'] ?? '')));
    $password = (string)($_POST['password'] ?? '');
    $passwordConfirm = (string)($_POST['password_confirm'] ?? '');
    $agreement = isset($_POST['agreement']) && $_POST['agreement'] === '1';

    if (!verify_csrf((string)($_POST['csrf_token'] ?? ''))) {
        $error = 'Сессия формы устарела. Обновите страницу и попробуйте снова.';
    } elseif (!valid_username($oldUsername)) {
        $error = 'Никнейм должен содержать от 3 до 32 букв, цифр или символов _.';
    } elseif (!filter_var($oldEmail, FILTER_VALIDATE_EMAIL)) {
        $error = 'Введите корректный адрес электронной почты.';
    } elseif (strlen($password) < 8) {
        $error = 'Пароль должен содержать минимум 8 символов.';
    } elseif ($password !== $passwordConfirm) {
        $error = 'Пароли не совпадают.';
    } elseif (!$agreement) {
        $error = 'Необходимо принять условия использования.';
    } else {
        try {
            $pdo = db();
            $stmt = $pdo->prepare('SELECT id, email_verified FROM users WHERE email = ? OR username = ? LIMIT 1');
            $stmt->execute([$oldEmail, $oldUsername]);
            $existing = $stmt->fetch();

            if ($existing && (int)$existing['email_verified'] === 1) {
                $error = 'Пользователь с таким email или никнеймом уже существует.';
            } else {
                $pdo->beginTransaction();

                if ($existing) {
                    $userId = (int)$existing['id'];
                    $stmt = $pdo->prepare('UPDATE users SET username = ?, email = ?, password_hash = ?, email_verified = 0 WHERE id = ?');
                    $stmt->execute([$oldUsername, $oldEmail, password_hash($password, PASSWORD_DEFAULT), $userId]);
                } else {
                    $stmt = $pdo->prepare('INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)');
                    $stmt->execute([$oldUsername, $oldEmail, password_hash($password, PASSWORD_DEFAULT)]);
                    $userId = (int)$pdo->lastInsertId();
                }

                $token = bin2hex(random_bytes(32));
                $tokenHash = password_hash($token, PASSWORD_DEFAULT);
                $expires = date('Y-m-d H:i:s', time() + CODE_LIFETIME);
                $now = date('Y-m-d H:i:s');

                $stmt = $pdo->prepare('INSERT INTO email_verifications (user_id, code_hash, expires_at, last_sent_at) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE code_hash = VALUES(code_hash), expires_at = VALUES(expires_at), last_sent_at = VALUES(last_sent_at), created_at = CURRENT_TIMESTAMP');
                $stmt->execute([$userId, $tokenHash, $expires, $now]);

                if (!send_verification_email($userId, $oldEmail, $oldUsername, $token)) {
                    $pdo->rollBack();
                    $error = 'Не удалось отправить письмо на почту. Проверьте настройки SMTP в config.php.';
                } else {
                    $pdo->commit();
                    start_session();
                    $_SESSION['pending_verification_user_id'] = $userId;
                    redirect('/ru/verify/');
                }
            }
        } catch (Throwable $e) {
            if (isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = 'Не удалось создать аккаунт. Проверьте подключение к базе данных.';
        }
    }
}

$page_title = 'Регистрация — AverionLand';
require __DIR__ . '/includes/header.php';
?>
<main class="auth-page">
<section class="auth-card">
<h1>Регистрация</h1>
<?php if ($error): ?><div class="message error"><?= e($error) ?></div><?php endif; ?>
<form class="auth-form" method="post" action="/ru/register/" autocomplete="on">
<input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
<div class="input-wrap">
<input type="text" name="username" value="<?= e($oldUsername) ?>" placeholder="Игровой никнейм" maxlength="32" required autocomplete="username">
<svg class="input-icon" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 12a5 5 0 1 0-5-5 5 5 0 0 0 5 5Zm0 2c-4.42 0-8 2.24-8 5v1h16v-1c0-2.76-3.58-5-8-5Z"/></svg>
</div>
<div class="input-wrap">
<input type="email" name="email" value="<?= e($oldEmail) ?>" placeholder="Ваша почта" maxlength="190" required autocomplete="email">
<svg class="input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M8 15c1.5 1.5 6.5 1.5 8-2 .8-1.8-.1-4-2-4-1.4 0-2.2 1.1-2.2 2.5S12.7 14 14 14c1.4 0 2.4-.9 2.9-2"/></svg>
</div>
<div class="input-wrap">
<input type="password" name="password" placeholder="Пароль" minlength="8" required autocomplete="new-password">
<svg class="input-icon" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M17 9h-1V7a4 4 0 0 0-8 0v2H7a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-7a2 2 0 0 0-2-2Zm-7-2a2 2 0 0 1 4 0v2h-4V7Zm2 9a2 2 0 1 1 0-4 2 2 0 0 1 0 4Z"/></svg>
</div>
<div class="input-wrap">
<input type="password" name="password_confirm" placeholder="Повторите пароль" minlength="8" required autocomplete="new-password">
<svg class="input-icon" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M17 9h-1V7a4 4 0 0 0-8 0v2H7a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-7a2 2 0 0 0-2-2Zm-7-2a2 2 0 0 1 4 0v2h-4V7Zm2 9a2 2 0 1 1 0-4 2 2 0 0 1 0 4Z"/></svg>
</div>
<label class="agreement">
<input type="checkbox" name="agreement" value="1" required>
<span class="check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12 4 4L19 7"/></svg></span>
<span>Я принимаю Условия использования, Лицензионное соглашение, Политику Cookie, Политику конфиденциальности и Правила сообщества</span>
</label>
<button class="auth-submit" type="submit">СОЗДАТЬ АККАУНТ</button>
</form>
<div class="auth-links"><a href="/ru/login/">У МЕНЯ УЖЕ ЕСТЬ АККАУНТ</a><span></span></div>
</section>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
