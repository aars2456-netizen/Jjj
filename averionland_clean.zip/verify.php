<?php
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/mail.php';
require_guest();
start_session();

$token = trim((string)($_GET['token'] ?? ''));
$userId = (int)($_SESSION['pending_verification_user_id'] ?? 0);

if ($token !== '') {
    $tokenUserId = (int)($_GET['uid'] ?? 0);
    $stmt = db()->prepare('SELECT ev.user_id, ev.code_hash, ev.expires_at, u.username, u.email, u.email_verified FROM email_verifications ev INNER JOIN users u ON u.id = ev.user_id WHERE ev.user_id = ? AND ev.expires_at >= NOW() LIMIT 1');
    $stmt->execute([$tokenUserId]);
    $verifiedUser = $stmt->fetch();

    if ($verifiedUser && !password_verify($token, $verifiedUser['code_hash'])) {
        $verifiedUser = null;
    }

    if (!$verifiedUser) {
        $page_title = 'Подтверждение — AverionLand';
        require __DIR__ . '/includes/header.php';
        ?>
        <main class="auth-page">
        <section class="auth-card">
        <h1>Ссылка недействительна</h1>
        <p class="auth-note">Ссылка для подтверждения регистрации недействительна или срок её действия истёк.</p>
        <div class="verification-actions"><form action="/ru/resend-code/" method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><button class="auth-submit accent verification-resend" type="submit">ОТПРАВИТЬ ПИСЬМО ЕЩЁ РАЗ</button></form><a class="verification-back" href="/ru/register/">РЕГИСТРАЦИЯ</a></div>
        </section>
        </main>
        <?php require __DIR__ . '/includes/footer.php'; ?>
        <?php
        exit;
    }

    $userId = (int)$verifiedUser['user_id'];
    $pdo = db();
    $pdo->beginTransaction();
    $stmt = $pdo->prepare('UPDATE users SET email_verified = 1 WHERE id = ?');
    $stmt->execute([$userId]);
    $stmt = $pdo->prepare('DELETE FROM email_verifications WHERE user_id = ?');
    $stmt->execute([$userId]);
    $pdo->commit();
    session_regenerate_id(true);
    $_SESSION['user_id'] = $userId;
    unset($_SESSION['pending_verification_user_id']);
    set_flash('success', 'Электронная почта подтверждена. Добро пожаловать!');
    redirect('account.php');
}

if ($userId <= 0) {
    redirect('register.php');
}

$stmt = db()->prepare('SELECT id, username, email, email_verified FROM users WHERE id = ? LIMIT 1');
$stmt->execute([$userId]);
$user = $stmt->fetch();

if (!$user) {
    unset($_SESSION['pending_verification_user_id']);
    redirect('register.php');
}

if ((int)$user['email_verified'] === 1) {
    $_SESSION['user_id'] = $userId;
    unset($_SESSION['pending_verification_user_id']);
    redirect('account.php');
}

$page_title = 'Подтверждение — AverionLand';
require __DIR__ . '/includes/header.php';
?>
<main class="auth-page">
<section class="auth-card">
<h1>Почта</h1>
<p class="auth-note">Мы отправили письмо с кнопкой подтверждения на <strong class="account-email"><?= e($user['email']) ?></strong></p>
<div class="mail-confirmation">
<div class="mail-icon" aria-hidden="true">✉</div>
<p>Откройте письмо от AverionLand и нажмите «Подтвердить регистрацию».</p>
</div>
<div class="verification-actions">
<form action="/resend-code.php" method="post">
<input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
<button class="auth-submit accent verification-resend" type="submit">ОТПРАВИТЬ ПИСЬМО ЕЩЁ РАЗ</button>
</form>
<a class="verification-back" href="/ru/register/">НАЗАД</a>
</div>
</section>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
